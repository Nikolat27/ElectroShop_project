$(document).ready(function () {
    $("#LoadMore").on('click', function () {
        let currentProducts = $(".product-box").length;
        let limit = $(this).attr("data-limit")
        let total_products = $(this).attr("data-total")
        console.log(`current: ${currentProducts} - limit: ${limit} - total: ${total_products}`)

        //Start Ajax
        $.ajax({
            url: "/products/load-more-data",
            data: {
                limit: limit,
                start: currentProducts
            },
            dataType: "json",
            beforeSend: function () {
                $(".LoadMore").attr('disabled', true);
                $(".load-more-icon").addClass('fa-spin');
            },
            success: function (response) {
                $("#filteredProducts").append(response.data)
                $(".LoadMore").attr('disabled', false);
                $(".load-more-icon").removeClass('fa-spin');

                let totalShowing = $(".product-box").length;
                console.log("total showing: ", totalShowing)

                if (totalShowing == total_products) {
                    $("#LoadMore").remove();
                }
            }
        });
        //End
    });
});